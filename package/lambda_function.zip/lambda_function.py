import json
import boto3
from PIL import Image
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    if key.startswith("thumbnails/"):
        return

    download_path = f'/tmp/{os.path.basename(key)}'
    upload_path = f'/tmp/thumb-{os.path.basename(key)}'

    s3.download_file(bucket, key, download_path)

    with Image.open(download_path) as img:
        img.thumbnail((200, 200))
        img.save(upload_path)

    thumbnail_key = f'thumbnails/thumb-{os.path.basename(key)}'

    s3.upload_file(upload_path, bucket, thumbnail_key)

    return {
        'statusCode': 200,
        'body': json.dumps('Thumbnail created successfully!')
    }